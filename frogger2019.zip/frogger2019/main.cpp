#define _USE_MATH_DEFINES
#include<math.h>
#include<stdio.h>
#include<string.h>
#include<windows.h>

extern "C" {
#include"SDL2-2.0.10/include/SDL.h"
#include"SDL2-2.0.10/include/SDL_main.h"
}


#define SCREEN_WIDTH	800
#define SCREEN_HEIGHT	800
#define SPEED 0.3


// narysowanie napisu txt na powierzchni screen, zaczynaj�c od punktu (x, y)
// charset to bitmapa 128x128 zawieraj�ca znaki
// draw a text txt on surface screen, starting from the point (x, y)
// charset is a 128x128 bitmap containing character images
void DrawString(SDL_Surface * screen, int x, int y, const char* text,
	SDL_Surface * charset) {
	int px, py, c;
	SDL_Rect s, d;
	s.w = 8;
	s.h = 8;
	d.w = 8;
	d.h = 8;
	while (*text) {
		c = *text & 255;
		px = (c % 16) * 8;
		py = (c / 16) * 8;
		s.x = px;
		s.y = py;
		d.x = x;
		d.y = y;
		SDL_BlitSurface(charset, &s, screen, &d);
		x += 8;
		text++;
	};
};


// narysowanie na ekranie screen powierzchni sprite w punkcie (x, y)
// (x, y) to punkt �rodka obrazka sprite na ekranie
// draw a surface sprite on a surface screen in point (x, y)
// (x, y) is the center of sprite on screen
void DrawSurface(SDL_Surface* screen, SDL_Surface* sprite, double x, double y) {
	SDL_Rect dest;
	dest.x = x - sprite->w / 2;
	dest.y = y - sprite->h / 2;
	dest.w = sprite->w;
	dest.h = sprite->h;
	SDL_BlitSurface(sprite, NULL, screen, &dest);
};


// rysowanie pojedynczego pixela
// draw a single pixel
void DrawPixel(SDL_Surface* surface, int x, int y, Uint32 color) {
	int bpp = surface->format->BytesPerPixel;
	Uint8* p = (Uint8*)surface->pixels + y * surface->pitch + x * bpp;
	*(Uint32*)p = color;
};


// rysowanie linii o d�ugo�ci l w pionie (gdy dx = 0, dy = 1) 
// b�d� poziomie (gdy dx = 1, dy = 0)
// draw a vertical (when dx = 0, dy = 1) or horizontal (when dx = 1, dy = 0) line
void DrawLine(SDL_Surface* screen, int x, int y, int l, int dx, int dy, Uint32 color) {
	for (int i = 0; i < l; i++) {
		DrawPixel(screen, x, y, color);
		x += dx;
		y += dy;
	};
};


// rysowanie prostok�ta o d�ugo�ci bok�w l i k
// draw a rectangle of size l by k
void DrawRectangle(SDL_Surface* screen, int x, int y, int l, int k,
	Uint32 outlineColor, Uint32 fillColor) {
	int i;
	DrawLine(screen, x, y, k, 0, 1, outlineColor);
	DrawLine(screen, x + l - 1, y, k, 0, 1, outlineColor);
	DrawLine(screen, x, y, l, 1, 0, outlineColor);
	DrawLine(screen, x, y + k - 1, l, 1, 0, outlineColor);
	for (i = y + 1; i < y + k - 1; i++)
		DrawLine(screen, x + 1, i, l - 2, 1, 0, fillColor);
};


// main
#ifdef __cplusplus
extern "C"
#endif
int main(int argc, char** argv) {
	
	int t1, t2, quit, frames, rc, lifes = 5, deathcounter = 0, move = 0, schoweknaczas = 0, pauzacounter = 0, quitcounter=0;
	int tablicanapoziome[6], points = 0, zaba1punkty=0, zaba2punkty=0, zaba3punkty=0, zaba4punkty=0, zaba5punkty=0;
	char choice='a';
	int gameoverway = 400;
	double audiway, daciaway, astonway, lamborghiniway;
	double delta, worldTime, fpsTimer, fps, distance, etiSpeed, galapagosway, trzecizolwway, turtleway, wiuryway, deskiway, woodway, pion, poziom;
	bool jump = false, jump2 = false, jump3 = false, jump4 = false, jump4poziom = false, jump5 = false, jump6 = false, jump7 = false,
		jump8 = false, jump9 = false, first = false, second = false, third = false, fourth = false, fifth = false, zgon = false, koniecgry=false,jump10 = false, 
		czas=false, skokpunkty=false, skokpunkty1=false, skokpunkty2=false, skokpunkty3=false, skokpunkty4=false, skokpunkty5=false, zaba1wynik=false, 
		zaba2wynik=false, zaba3wynik=false, zaba4wynik=false, zaba5wynik=false, pauza=false, przywroc=false, startgame=true, quitgame=false, zwyciestwo=false;
	SDL_Event event;
	SDL_Surface* screen, * charset, *zegar, *paused, *start, *victory;
	//SDL_Surface* eti;
	SDL_Surface* eti, * plansza, * frog, * bale, * wiury, * deski, * zolw, * galapagos, * dacia, * audi, * aston, * lamborghini,
		* frogonaudi, * frogondacia, * frogonaston, * frogonlamborghini, * frogonturtle, * frogonwiury, * frogondeski, * frogonwood, * frogongalapagos, * gameover, * death, * wygrana, * trzecizolw, * frogontrzecizolw;
	SDL_Rect wycinek, wycinek2, wycinek3, wycinek4, wycinek5, wycinek6, wycinek7, wycinek8, wycinek9, wycinek10, wycinek11, wycinek12;
	SDL_Texture* scrtex;
	SDL_Window* window;
	SDL_Renderer* renderer;

	// okno konsoli nie jest widoczne, je�eli chcemy zobaczy�
	// komunikaty wypisywane printf-em trzeba w opcjach:
	// project -> szablon2 properties -> Linker -> System -> Subsystem
	// zmieni� na "Console"
	// console window is not visible, to see the printf output
	// the option:
	// project -> szablon2 properties -> Linker -> System -> Subsystem
	// must be changed to "Console"
	printf("wyjscie printfa trafia do tego okienka\n");
	printf("printf output goes here\n");

	if (SDL_Init(SDL_INIT_EVERYTHING) != 0) {
		printf("SDL_Init error: %s\n", SDL_GetError());
		return 1;
	}

	// tryb pe�noekranowy / fullscreen mode
//	rc = SDL_CreateWindowAndRenderer(0, 0, SDL_WINDOW_FULLSCREEN_DESKTOP,
//	                                 &window, &renderer);
	rc = SDL_CreateWindowAndRenderer(SCREEN_WIDTH, SCREEN_HEIGHT, 0,
		&window, &renderer);
	if (rc != 0) {
		SDL_Quit();
		printf("SDL_CreateWindowAndRenderer error: %s\n", SDL_GetError());
		return 1;
	};

	SDL_SetHint(SDL_HINT_RENDER_SCALE_QUALITY, "linear");
	SDL_RenderSetLogicalSize(renderer, SCREEN_WIDTH, SCREEN_HEIGHT);
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);

	SDL_SetWindowTitle(window, "Frogger");


	screen = SDL_CreateRGBSurface(0, SCREEN_WIDTH, SCREEN_HEIGHT, 32,
		0x00FF0000, 0x0000FF00, 0x000000FF, 0xFF000000);

	scrtex = SDL_CreateTexture(renderer, SDL_PIXELFORMAT_ARGB8888,
		SDL_TEXTUREACCESS_STREAMING,
		SCREEN_WIDTH, SCREEN_HEIGHT);


	// wy��czenie widoczno�ci kursora myszy
	SDL_ShowCursor(SDL_DISABLE);

	// wczytanie obrazka cs8x8.bmp
	charset = SDL_LoadBMP("cs8x8.bmp");
	if (charset == NULL) {
		printf("SDL_LoadBMP(cs8x8.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	};
	SDL_SetColorKey(charset, true, 0x000000);

	plansza = SDL_LoadBMP("planszafrogger.bmp");
	if (plansza == NULL)
	{
		printf("SDL_LoadBMP(planszafrogger.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	frog = SDL_LoadBMP("zabka3.bmp");
	if (frog == NULL)
	{
		printf("SDL_LoadBMP(zabka3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	bale = SDL_LoadBMP("drewno3.bmp");
	if (bale == NULL)
	{
		printf("SDL_LoadBMP(drewno3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	wiury = SDL_LoadBMP("wiury.bmp");
	if (wiury == NULL)
	{
		printf("SDL_LoadBMP(wiury.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	deski = SDL_LoadBMP("deski.bmp");
	if (deski == NULL)
	{
		printf("SDL_LoadBMP(deski.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	zolw = SDL_LoadBMP("turtle3.bmp");
	if (zolw == NULL)
	{
		printf("SDL_LoadBMP(turtle3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	galapagos = SDL_LoadBMP("galapagos.bmp");
	if (galapagos == NULL)
	{
		printf("SDL_LoadBMP(galapagos.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	dacia = SDL_LoadBMP("duster.bmp");
	if (dacia == NULL)
	{
		printf("SDL_LoadBMP(duster.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	audi = SDL_LoadBMP("audi2.bmp");
	if (audi == NULL)
	{
		printf("SDL_LoadBMP(audi2.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	aston = SDL_LoadBMP("aston.bmp");
	if (aston == NULL)
	{
		printf("SDL_LoadBMP(aston.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	lamborghini = SDL_LoadBMP("lamborghini.bmp");
	if (lamborghini == NULL)
	{
		printf("SDL_LoadBMP(lamborghini.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	trzecizolw = SDL_LoadBMP("trzecizolw.bmp");
	if (trzecizolw == NULL)
	{
		printf("SDL_LoadBMP(trzecizolw.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	frogontrzecizolw = SDL_LoadBMP("trzecizolw.bmp");
	if (frogontrzecizolw == NULL)
	{
		printf("SDL_LoadBMP(trzecizolw.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	frogonaudi = SDL_LoadBMP("audi2.bmp");
	if (frogonaudi == NULL)
	{
		printf("SDL_LoadBMP(audi.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;

	}
	frogondacia = SDL_LoadBMP("duster.bmp");
	if (frogondacia == NULL)
	{
		printf("SDL_LoadBMP(duster.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogonaston = SDL_LoadBMP("aston.bmp");
	if (frogonaston == NULL)
	{
		printf("SDL_LoadBMP(aston.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogonlamborghini = SDL_LoadBMP("lamborghini.bmp");
	if (frogondacia == NULL)
	{
		printf("SDL_LoadBMP(duster.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogonturtle = SDL_LoadBMP("turtle3.bmp");
	if (frogonturtle == NULL)
	{
		printf("SDL_LoadBMP(turtle3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogonwood = SDL_LoadBMP("drewno3.bmp");
	if (frogonwood == NULL)
	{
		printf("SDL_LoadBMP(drewno3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogonwiury = SDL_LoadBMP("wiury.bmp");
	if (frogonwiury == NULL)
	{
		printf("SDL_LoadBMP(wiury.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogondeski = SDL_LoadBMP("deski.bmp");
	if (frogondeski == NULL)
	{
		printf("SDL_LoadBMP(deski.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	frogongalapagos = SDL_LoadBMP("galapagos.bmp");
	if (frogongalapagos == NULL)
	{
		printf("SDL_LoadBMP(galapagos.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	gameover = SDL_LoadBMP("gameover3.bmp");
	if (gameover == NULL)
	{
		printf("SDL_LoadBMP(gameover3.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	death = SDL_LoadBMP("death.bmp");
	if (death == NULL)
	{
		printf("SDL_LoadBMP(death.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	wygrana = SDL_LoadBMP("frog.bmp");
	if (wygrana == NULL)
	{
		printf("SDL_LoadBMP(frog.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	paused = SDL_LoadBMP("paused.bmp");
	if (paused == NULL)
	{
		printf("SDL_LoadBMP(paused.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}
	start = SDL_LoadBMP("start3.bmp");
	if (start == NULL)
	{
		printf("SDL_LoadBMP(start2.bmp) error: %s\n", SDL_GetError());
		SDL_FreeSurface(charset);
		SDL_FreeSurface(screen);
		SDL_DestroyTexture(scrtex);
		SDL_DestroyWindow(window);
		SDL_DestroyRenderer(renderer);
		SDL_Quit();
		return 1;
	}


	wycinek.x = 30;
	wycinek.y = 0;
	wycinek.w = 32;
	wycinek.h = 32;

	wycinek2.x = 25;
	wycinek2.y = 0;
	wycinek2.w = 25;
	wycinek2.h = 25;

	wycinek3.x = 30;
	wycinek3.y = 0;
	wycinek3.w = 33;
	wycinek3.h = 33;

	wycinek4.x = 15;
	wycinek4.y = 0;
	wycinek4.w = 33;
	wycinek4.h = 33;

	wycinek5.x = 30;
	wycinek5.y = 0;
	wycinek5.w = 50;
	wycinek5.h = 50;

	wycinek6.x = 30;
	wycinek6.y = 0;
	wycinek6.w = 32;
	wycinek6.h = 32;

	wycinek7.x = 25;
	wycinek7.y = 0;
	wycinek7.w = 25;
	wycinek7.h = 25;

	wycinek8.x = 30;
	wycinek8.y = 0;
	wycinek8.w = 33;
	wycinek8.h = 33;

	wycinek9.x = 30;
	wycinek9.y = 0;
	wycinek9.w = 33;
	wycinek9.h = 33;

	wycinek10.x = 100;
	wycinek10.y = 0;
	wycinek10.w = 50;
	wycinek10.h = 50;


	wycinek11.x = 30;
	wycinek11.y = 0;
	wycinek11.w = 33;
	wycinek11.h = 33;

	wycinek12.x = 30;
	wycinek12.y = 0;
	wycinek12.w = 32;
	wycinek12.h = 32;

	SDL_BlitSurface(frog, NULL, frogonaudi, &wycinek);
	SDL_BlitSurface(frog, NULL, frogondacia, &wycinek2);
	SDL_BlitSurface(frog, NULL, frogonturtle, &wycinek3);
	SDL_BlitSurface(frog, NULL, frogonwood, &wycinek4);
	SDL_BlitSurface(frog, NULL, frogonaston, &wycinek5);
	SDL_BlitSurface(frog, NULL, frogonlamborghini, &wycinek6);
	SDL_BlitSurface(frog, NULL, frogongalapagos, &wycinek7);
	SDL_BlitSurface(frog, NULL, frogonwiury, &wycinek8);
	SDL_BlitSurface(frog, NULL, frogondeski, &wycinek9);
	SDL_BlitSurface(frog, NULL, frogontrzecizolw, &wycinek11);
	SDL_BlitSurface(gameover, NULL, screen, &wycinek12);
	SDL_BlitSurface(death, NULL, screen, &wycinek5);
	SDL_BlitSurface(paused, NULL, screen, &wycinek12);




	char text[128];
	int czarny = SDL_MapRGB(screen->format, 0x00, 0x00, 0x00);
	int zielony = SDL_MapRGB(screen->format, 0x00, 0xFF, 0x00);
	int czerwony = SDL_MapRGB(screen->format, 0xFF, 0x00, 0x00);
	int niebieski = SDL_MapRGB(screen->format, 0x11, 0x11, 0xCC);

	t1 = SDL_GetTicks();

	frames = 0;
	fpsTimer = 0;
	fps = 0;
	quit = 0;
	worldTime = 0;
	distance = 0;
	etiSpeed = 1;
	pion = 10;
	poziom = 10;
	woodway = -760;
	turtleway = -10;
	audiway = 1;
	daciaway = 1;
	galapagosway = -340;
	astonway = -250;
	lamborghiniway = -200;
	deskiway = -400;
	wiuryway = -50;
	trzecizolwway = -710;

	DrawSurface(screen, plansza, 0, 0);
	
	while (!quit) {

		if (startgame == true)
		{

			SDL_FillRect(screen, NULL, czarny);

			SDL_BlitSurface(start, NULL, screen, NULL);
			DrawRectangle(screen, 280, 300, 300, 30, czerwony, niebieski);
			//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
			sprintf(text, "y-rozpocznij gre, x-wyjdz");
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 , 310, text, charset);
			points = 0;
		}
		else
		{
			t2 = SDL_GetTicks();

			// w tym momencie t2-t1 to czas w milisekundach,
			// jaki uplyna� od ostatniego narysowania ekranu
			// delta to ten sam czas w sekundach
			// here t2-t1 is the time in milliseconds since
			// the last screen was drawn
			// delta is the same time in seconds
			delta = (t2 - t1) * 0.001;
			t1 = t2;

			worldTime += delta;

			distance += etiSpeed * delta;

			SDL_FillRect(screen, NULL, czarny);

			SDL_BlitSurface(plansza, NULL, screen, NULL);

			/*DrawSurface(screen, eti,
				SCREEN_WIDTH / 2 + sin(distance) * SCREEN_HEIGHT / 3,
				SCREEN_HEIGHT / 2 + cos(distance) * SCREEN_HEIGHT / 3); */

			DrawSurface(screen, zolw, turtleway, SCREEN_HEIGHT / 3);
			//	DrawSurface(screen, gameover, turtleway, SCREEN_HEIGHT / 3+200);

			//mechanizm wy�wietlaj�cy zapytanie o dalsz� gr�
			if (lifes < 1)
			{
				//SDL_RenderPresent(g_pRenderer);
				DrawSurface(screen, gameover, SCREEN_WIDTH / 2 + 18, SCREEN_HEIGHT / 3 + 80);

				DrawRectangle(screen, 500, 330, 300, 30, czerwony, czarny);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Czy zakonczyc gre?( y-tak, n-nie)");
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 250, 345, text, charset);
				worldTime = 0;
				//sprintf("/nNiestety przegrales. Czy chcesz grac wiecej?(y-tak , n -nie)/n");
				koniecgry = true;
			}

			
			//mechanizm rysowania pojazduw, zolwi i bali
			DrawSurface(screen, bale, woodway, SCREEN_HEIGHT / 4 - 45);

			DrawSurface(screen, audi, audiway, SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60);

			DrawSurface(screen, galapagos, galapagosway, SCREEN_HEIGHT / 3);

			DrawSurface(screen, trzecizolw, trzecizolwway, SCREEN_HEIGHT / 3);

			DrawSurface(screen, aston, astonway, SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60);

			DrawSurface(screen, lamborghini, lamborghiniway, SCREEN_HEIGHT / 2 + 120);

			DrawSurface(screen, deski, deskiway, SCREEN_HEIGHT / 4 - 45);

			DrawSurface(screen, wiury, wiuryway, SCREEN_HEIGHT / 4 - 45);

			DrawSurface(screen, dacia, daciaway, SCREEN_HEIGHT / 2 + 120);

			//mechanizm zakazujacy frogerowi wychodzenie poza plansze
			if (pion > 750)
			{
				pion = pion - 118;
			}
			else if (pion < 0)
			{
				pion = pion + 118;
			}

			if (poziom < -500)
			{
				poziom = poziom + 175;
			}
			else if (poziom > 500)
			{
				poziom = poziom - 175;
			}

			//mechanizm �mierci gdy froger pr�buje wskoczy� w zaj�te przez wielk� �ab� pole
			if ((pion == 718 && poziom > -400 && poziom < -303) && first == true)
			{
				pion = 10;
				poziom = 10;
				Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				//	Sleep(2000);
				deathcounter++;
				lifes--;
				zgon = true;

			}
			if ((pion == 718 && poziom > -197 && poziom < -122) && second == true)
			{
				pion = 10;
				poziom = 10;
				Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				//	Sleep(2000);
				deathcounter++;
				lifes--;
				zgon = true;

			}
			if ((pion == 718 && poziom > -16 && poziom < 59) && third == true)
			{
				pion = 10;
				poziom = 10;
				Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				//	Sleep(2000);
				deathcounter++;
				lifes--;
				zgon = true;

			}
			if ((pion == 718 && poziom > 175 && poziom < 250) && fourth == true)
			{
				pion = 10;
				poziom = 10;
				Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				//	Sleep(2000);
				deathcounter++;
				lifes--;
				zgon = true;

			}
			if ((pion == 718 && poziom > 356) && fifth == true)
			{
				pion = 10;
				poziom = 10;
				Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				//	Sleep(2000);
				deathcounter++;
				lifes--;
				zgon = true;

			}

			//mechanizm obs�uguj�cy zdarzenie gdy froger wskoczy na jaki� obiekt

			//audi
			if ((SCREEN_WIDTH / 2 + poziom + 8 > audiway - 20 && SCREEN_WIDTH / 2 + poziom + 8 < audiway + 20) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60 - 20 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60 + 20))
			{
				jump = true;
			}

			//dacia
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > daciaway - 20 && SCREEN_WIDTH / 2 + poziom + 8 < daciaway + 20) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 2 + 120 - 20 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 2 + 120 + 20))
			{
				jump2 = true;
			}
			//turtle
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > turtleway - 100 && SCREEN_WIDTH / 2 + poziom + 8 < turtleway + 100) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 3 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 3 + 40))
			{
				jump3 = true;
				poziom = poziom + SPEED;
			}
			// wood
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > woodway - 150 && SCREEN_WIDTH / 2 + poziom + 8 < woodway + 150) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 4 - 45 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 4 - 45 + 40))
			{
				jump4 = true;
				poziom = poziom + SPEED;
			}
			//aston
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > astonway - 20 && SCREEN_WIDTH / 2 + poziom + 8 < astonway + 20) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60 - 20 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60 + 20))
			{
				jump5 = true;
			}
			// lamborghini
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > lamborghiniway - 20 && SCREEN_WIDTH / 2 + poziom + 8 < lamborghiniway + 20) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 2 + 120 - 20 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 2 + 120 + 20))
			{
				jump6 = true;
			}
			//galapagos
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > galapagosway - 100 && SCREEN_WIDTH / 2 + poziom + 8 < galapagosway + 100) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 3 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 3 + 40))
			{
				jump7 = true;
				poziom = poziom + SPEED;
			}
			//deski
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > deskiway - 150 && SCREEN_WIDTH / 2 + poziom + 8 < deskiway + 150) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 4 - 45 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 4 - 45 + 40))
			{
				jump8 = true;
				poziom = poziom + SPEED;
			}
			//wiury
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > wiuryway - 150 && SCREEN_WIDTH / 2 + poziom + 8 < wiuryway + 150) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 4 - 45 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 4 - 45 + 40))
			{
				jump9 = true;
				poziom = poziom + SPEED;
			}
			//trzecizolw
			else if ((SCREEN_WIDTH / 2 + poziom + 8 > trzecizolwway - 100 && SCREEN_WIDTH / 2 + poziom + 8 < trzecizolwway + 100) && (SCREEN_HEIGHT - pion - 20 > SCREEN_HEIGHT / 3 - 40 && SCREEN_HEIGHT - pion - 20 < SCREEN_HEIGHT / 3 + 40))
			{
				jump10 = true;
				poziom = poziom + SPEED;
			}

			//mechaznim �mierci frogera gdy nie uda mu si� wskoczy� w przesmyk, zamiast tego wskakuje w pas zieleni
			if (pion == 718)
			{
				if ((poziom > -303 && poziom < -197) || (poziom > -122 && poziom < -16) || (poziom > 59 && poziom < 175) || (poziom > 250 && poziom < 356))
				{
					pion = 10;
					poziom = 10;
					DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
					//Sleep(2000);
					deathcounter++;

					jump4 = false;
					jump9 = false;
					jump8 = false;
					lifes--;
					zgon = true;
				}

			}
			/*	if (pion < -400 || pion >718 || poziom > 400 || poziom < -400)
				{
					DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20 );
					//Sleep(2000);
					deathcounter++;
					pion = 10;
					poziom = 10;
					lifes--;
				} */



			//mechanizm rysowania frogera znajduj�cego si� na obiekcie
			if (jump3 == true) {

				DrawSurface(screen, frogonturtle, turtleway, SCREEN_HEIGHT / 3);
				if (pion != 482)
					jump3 = false;

			}
			else if (jump7 == true) {

				DrawSurface(screen, frogongalapagos, galapagosway, SCREEN_HEIGHT / 3);
				if (pion != 482)
					jump7 = false;

			}
			else if (jump4 == true) {

				DrawSurface(screen, frogonwood, woodway, SCREEN_HEIGHT / 4 - 45);
				if (pion != 600)
					jump4 = false;

			}
			else if (jump8 == true) {

				DrawSurface(screen, frogondeski, deskiway, SCREEN_HEIGHT / 4 - 45);
				if (pion != 600)
					jump8 = false;

			}
			else if (jump9 == true)
			{
				DrawSurface(screen, frogonwiury, wiuryway, SCREEN_HEIGHT / 4 - 45);
				if (pion != 600)
					jump9 = false;

			}
			else if (jump10 == true)
			{
				DrawSurface(screen, frogontrzecizolw, trzecizolwway, SCREEN_HEIGHT / 3);
				if (pion != 482)
					jump10 = false;

			}
			//mechanizm rysowania frogera gdy nie znajduje si� na �adnym obiekcie
			if (jump3 == false && jump4 == false && jump7 == false && jump8 == false && jump9 == false && jump10 == false)
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);


			//mechanizm �mierci frogera gdy si� zderzy z pojazdami
			if ((pion == 128 || pion == 246 || pion == 482) && (jump == true || jump2 == true || jump5 == true || jump6 == true))
			{
				pion = 10;
				poziom = 10;
				//Sleep(2000);
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				Sleep(2000);
				jump = false;
				jump2 = false;
				jump5 = false;
				jump6 = false;
				deathcounter++;
				lifes--;
				zgon = true;
			}
			//mechanizm �mierci frogera gdy zamiast na ��wia lub bal wskoczy w wod�
			if ((pion == 482 || pion == 600) && jump3 == false && jump4 == false && jump7 == false && jump8 == false && jump9 == false && jump10 == false)
			{

				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				Sleep(2000);
				pion = 10;
				poziom = 10;
				deathcounter++;
				lifes--;
				zgon = true;
			}
			//mechanizm �mierci frogera gdy b�d�c na obiekcie wyjedzie poza plansz�
			if ((jump3 == true && turtleway > 800) || (jump4 == true && woodway > 800) || (jump7 == true && galapagosway > 800) || (jump8 == true && deskiway > 800) || (jump9 == true && wiuryway > 800) || (jump10 == true && trzecizolwway > 800))
			{
				pion = 10;
				poziom = 10;
				//	DrawSurface(plansza, death, carway, SCREEN_HEIGHT - SCREEN_HEIGHT / 4 + 60);
				Sleep(2000);
				jump3 = false;
				jump4 = false;
				jump7 = false;
				jump8 = false;
				jump9 = false;
				jump10 = false;
				deathcounter++;
				lifes--;
				zgon = true;
			} 


			//mechaznizm wskoczenia frogera w 1 z niezaj�tych 5 p�l na mecie
			if ((pion == 718 && poziom > -400 && poziom < -303) && first == false)
			{

				DrawSurface(plansza, wygrana, SCREEN_WIDTH / 10 - 20, SCREEN_HEIGHT / 12);
				first = true;
				points = points + 10;
				pion = 10;
				poziom = 10;
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				worldTime = 0;
			}
			if ((pion == 718 && poziom > -197 && poziom < -122) && second == false)
			{

				DrawSurface(plansza, wygrana, SCREEN_WIDTH / 5 + 80, SCREEN_HEIGHT / 12);
				second = true;
				points = points + 10;
				pion = 10;
				poziom = 10;
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				worldTime = 0;
			}
			if ((pion == 718 && poziom > -16 && poziom < 59) && third == false)
			{

				DrawSurface(plansza, wygrana, SCREEN_WIDTH / 3 + 150, SCREEN_HEIGHT / 12);
				third = true;
				points = points + 10;
				pion = 10;
				poziom = 10;
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				worldTime = 0;
			}
			if ((pion == 718 && poziom > 175 && poziom < 250) && fourth == false)
			{
				DrawSurface(plansza, wygrana, SCREEN_WIDTH / 2 + 195, SCREEN_HEIGHT / 12);
				fourth = true;
				points = points + 10;
				pion = 10;
				poziom = 10;
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				worldTime = 0;
			}
			if ((pion == 718 && poziom > 356) && fifth == false)
			{
				DrawSurface(plansza, wygrana, SCREEN_WIDTH / 2 + 360, SCREEN_HEIGHT / 12);
				fifth = true;
				points = points + 10;
				pion = 10;
				poziom = 10;
				DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
				worldTime = 0;
			}

			/*if (first == true && second == true && third == true && fourth == true && fifth == true)
			{
				
				DrawSurface(screen, victory, SCREEN_WIDTH / 2 + 18, SCREEN_HEIGHT / 3 + 80);
				if(zwyciestwo==false)
				zwyciestwo = true;

			}  */

			//mechanizm licz�cy pr�dko�� obiekt�w
			woodway = woodway + SPEED;
			if (woodway > 1600)
				woodway = 1;
			turtleway = turtleway + SPEED;
			if (turtleway > 1600)
				turtleway = 1;
			audiway++;
			if (audiway > 1600)
				audiway = 1;
			daciaway++;
			if (daciaway > 1600)
				daciaway = 1;
			galapagosway = galapagosway + SPEED;
			if (galapagosway > 1600)
				galapagosway = 1;
			astonway++;
			if (astonway > 1600)
				astonway = 1;
			lamborghiniway++;
			if (lamborghiniway > 1600)
				lamborghiniway = 1;
			deskiway = deskiway + SPEED;
			if (deskiway > 1600)
				deskiway = 1;
			wiuryway = wiuryway + SPEED;
			if (wiuryway > 1600)
				wiuryway = 1;
			trzecizolwway = trzecizolwway + SPEED;
			if (trzecizolwway > 1600)
				trzecizolwway = 1;

			//mechanizm obs�uguj�cy zdarzenie pauzy
			if (pauzacounter % 2 == 1)
			{
				woodway = woodway - SPEED;
				turtleway = turtleway - SPEED;
				audiway--;
				daciaway--;
				galapagosway = galapagosway - SPEED;
				astonway--;
				lamborghiniway--;
				deskiway = deskiway - SPEED;
				wiuryway = wiuryway - SPEED;
				trzecizolwway = trzecizolwway - SPEED;
				worldTime -= delta;
				DrawSurface(screen, paused, SCREEN_WIDTH / 2 + 18, SCREEN_HEIGHT / 3 + 80);
			}

			if (quitcounter % 2 == 1)
			{
				woodway = woodway - SPEED;
				turtleway = turtleway - SPEED;
				audiway--;
				daciaway--;
				galapagosway = galapagosway - SPEED;
				astonway--;
				lamborghiniway--;
				deskiway = deskiway - SPEED;
				wiuryway = wiuryway - SPEED;
				trzecizolwway = trzecizolwway - SPEED;
				worldTime -= delta;
				DrawRectangle(screen, 240, 340, SCREEN_WIDTH - 500, 100, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "QUIT GAME? Y/N");
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 390, text, charset);
			}




			//mechanizm obs�uguj�cy czas
			fpsTimer += delta;
			if (fpsTimer > 0.5) {
				fps = frames * 2;
				frames = 0;
				fpsTimer -= 0.5;
			};




			// tekst informacyjny / info text
			DrawRectangle(screen, 4, 1, SCREEN_WIDTH - 8, 20, czerwony, niebieski);
			//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
			sprintf(text, "Frogger, czas trwania = %.1lf s, Licznik smierci = %d, Lifes = %d, Esc-wyjscie", worldTime, deathcounter, lifes, fps);
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 10, text, charset);

			/*	else
				{
					// tekst informacyjny / info text
					DrawRectangle(screen, 4, 4, SCREEN_WIDTH - 8, 20, czerwony, niebieski);
					//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
					sprintf(text, "Frogger, Czy chcesz zagrac raz jeszcze ? (y-tak, n-nie) : ");
					DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 10, text, charset);
					//sscanf("%c", (const char *)choice);
				} */
				/*if (zgon == true)
				{
					switch (choice)
					{
						case 'y':
							lifes = 1;
							zgon = false;
						case 'n':
							exit(0);

					}

				}*/
			if (zgon == true)
			{
				points = 0;
				worldTime = 0;
				zgon = false;
			}

			//mechanizm punkt�w
			if (pion == 128 && jump2 == false && jump == false && skokpunkty == false)
			{
				points = points + 10;
				skokpunkty = true;
			}
			if (pion == 246 && jump2 == false && jump == false && skokpunkty2 == false)
			{
				points = points + 10;
				skokpunkty2 = true;
			}
			if (pion == 364 && skokpunkty3 == false)
			{
				points = points + 10;
				skokpunkty3 = true;
			}
			if (pion == 482 && (jump3 == true || jump7 == true || jump10 == true) && skokpunkty4 == false)
			{
				points = points + 10;
				skokpunkty4 = true;
			}
			if (pion == 600 && (jump4 == true || jump8 == true || jump9 == true) && skokpunkty5 == false)
			{
				points = points + 10;
				skokpunkty5 = true;
			}

			//mechaznim wy�wietlaj�cy punkty nad �abk�
			if (fifth == true)
			{
				if (zaba5wynik == false)
				{
					/*if (czas == false)
						zaba5punkty = points + 50 + ((30 - (int)worldTime) * 10);
					else if (czas == true)*/
						zaba5punkty = points + 50 + ((50 - (int)worldTime) * 10);
					zaba5wynik = true;
				}
				DrawRectangle(screen, 720, 20, 80, 15, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Zaba5=%d", zaba5punkty);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 363, 25, text, charset);
				points = 0;
			}
			if (fourth == true)
			{
				if (zaba4wynik == false)
				{
					/*if (czas == false)
						zaba4punkty = points + 50 + ((30 - (int)worldTime) * 10);
					else if (czas == true)*/
						zaba4punkty = points + 50 + ((50 - (int)worldTime) * 10);
					zaba4wynik = true;
				}
				DrawRectangle(screen, 555, 20, 80, 15, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Zaba4=%d", zaba4punkty);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 200, 25, text, charset);
				points = 0;
			}
			if (third == true)
			{
				if (zaba3wynik == false)
				{
					/*if (czas == false)
						zaba3punkty = points + 50 + ((30 - (int)worldTime) * 10);
					else if (czas == true)*/
						zaba3punkty = points + 50 + ((50 - (int)worldTime) * 10);
					zaba3wynik = true;
				}
				DrawRectangle(screen, 375, 20, 80, 15, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Zaba3=%d", zaba3punkty);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 10, 25, text, charset);
				points = 0;
			}
			if (second == true)
			{
				if (zaba2wynik == false)
				{
					/*if (czas == false)
						zaba2punkty = points + 50 + ((30 - (int)worldTime) * 10);
					else if (czas == true)*/
						zaba2punkty = points + 50 + ((50 - (int)worldTime) * 10);
					zaba2wynik = true;
				}
				DrawRectangle(screen, 200, 20, 80, 15, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Zaba2=%d", zaba2punkty);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 - 160, 25, text, charset);
				points = 0;
			}
			if (first == true)
			{
				if (zaba1wynik == false)
				{
					/*if (czas == false)
						zaba1punkty = points + 50 + ((30 - (int)worldTime) * 10);
					else if (czas == true) */
						zaba1punkty = points + 50 + ((50 - (int)worldTime) * 10);
					zaba1wynik = true;
				}
				DrawRectangle(screen, 22, 20, 80, 15, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Zaba1=%d", zaba1punkty);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 - 340, 25, text, charset);
				points = 0;
			}

			//mechaznim wy�wietlaj�cy punkty
			DrawRectangle(screen, 0, 775, SCREEN_WIDTH - 710, 30, czerwony, niebieski);
			//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
			sprintf(text, "Punkty=%d", points);
			DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 - 355, 780, text, charset);

			if (worldTime < 40)
			{
				DrawRectangle(screen, 710, 770, SCREEN_WIDTH - 710, 30, czerwony, niebieski);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Time=%.1lfs", worldTime);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 355, 780, text, charset);
			}
			else
			{
				DrawRectangle(screen, 710, 770, SCREEN_WIDTH - 710, 30, czerwony, czerwony);
				//            "template for the second project, elapsed time = %.1lf s  %.0lf frames / s"
				sprintf(text, "Time=%.1lfs", worldTime);
				DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2 + 355, 780, text, charset);
				if (worldTime > 50)
				{
					lifes--;
					pion = 10;
					poziom = 10;
					deathcounter++;
					DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
					czas = false;
					points = 0;
					worldTime = 0;
				}

			}

			//mechanizm obs�uguj�cy licznik czasu
			if (worldTime >= 40)
			{
				if (czas == false)
				{
					schoweknaczas = (int)worldTime;
					czas = true;
				}
				if ((int)worldTime == schoweknaczas + 10 && czas == true)
				{
					lifes--;
					pion = 10;
					poziom = 10;
					deathcounter++;
					points = 0;
					DrawSurface(screen, frog, SCREEN_WIDTH / 2 + poziom + 8, SCREEN_HEIGHT - pion - 20);
					czas = false;
				}
			}

		}

		//	      "Esc - exit, \030 - faster, \031 - slower"
		//sprintf(text, "Esc - wyjscie, \030 - przyspieszenie, \031 - zwolnienie");
	//	sprintf(text, "Lifes = %d", lifes);
		//DrawString(screen, screen->w / 2 - strlen(text) * 8 / 2, 26, text, charset);

		SDL_UpdateTexture(scrtex, NULL, screen->pixels, screen->pitch);
		//		SDL_RenderClear(renderer);
		SDL_RenderCopy(renderer, scrtex, NULL, NULL);
		SDL_RenderPresent(renderer);

		// obs�uga zdarze� (o ile jakie� zasz�y) / handling of events (if there were any)
		while (SDL_PollEvent(&event)) {
			switch (event.type) {
			case SDL_KEYDOWN:
				if (event.key.keysym.sym == SDLK_ESCAPE) quit = 1;
				if (startgame == true)
				{
					if (event.key.keysym.sym == SDLK_y)
					{
						pion = 10;
						poziom = 10;
						worldTime = 0;
						points = 0;
						lifes = 5;
						deathcounter = 0;
						koniecgry = false;
						startgame = false;
					}
					else if (event.key.keysym.sym == SDLK_x)
					{
						quit = 1;
					}

				}
				else if (koniecgry == true)
				{
					
					if (event.key.keysym.sym == SDLK_n)
					{
						pion = 10;
						poziom = 10;
						worldTime = 0;
						points = 0;
						lifes = 5;
						deathcounter = 0;
						koniecgry = false;
					}
					else if (event.key.keysym.sym == SDLK_y)
					{
						startgame=true;
					}
				}
			/*	else if (zwyciestwo == true)
				{

					if (event.key.keysym.sym == SDLK_n)
					{
						pion = 10;
						poziom = 10;
						worldTime = 0;
						points = 0;
						lifes = 1;
						deathcounter = 0;
						zwyciestwo = false;
					}
					else if (event.key.keysym.sym == SDLK_y)
					{
						zwyciestwo = false;
						startgame = true;
					} 


				}*/
				
				else {
					if (event.key.keysym.sym == SDLK_p)
					{
						pauzacounter++;

					}
					if (event.key.keysym.sym == SDLK_q)
					{
						quitcounter++;
						if (quitcounter % 2 == 1)
						{
							quitgame = true;
						}
					}
					if (quitgame == true)
					{
						if (event.key.keysym.sym == SDLK_y)
						{
							startgame = true;
							quitcounter--;
							quitgame = false;
						}
							
						else if (event.key.keysym.sym == SDLK_n)
						{
							quitcounter++;
							quitgame = false;
						}
							
					}
					 if (event.key.keysym.sym == SDLK_UP) pion = pion + 118;
					else if (event.key.keysym.sym == SDLK_DOWN) pion = pion - 118;
					else if (event.key.keysym.sym == SDLK_RIGHT)
					{
						poziom = poziom + 175;
					}
					else if (event.key.keysym.sym == SDLK_LEFT)
					{
						poziom = poziom - 175;
					}
				}
					break;
			case SDL_KEYUP:
				etiSpeed = 1.0;
				break;
			case SDL_QUIT:
				quit = 1;
				break;
			};
		};
		frames++;
	};

	// zwolnienie powierzchni / freeing all surfaces
	SDL_FreeSurface(charset);
	SDL_FreeSurface(screen);
	SDL_DestroyTexture(scrtex);
	SDL_DestroyRenderer(renderer);
	SDL_DestroyWindow(window);

	SDL_Quit();
	return 0;
};
